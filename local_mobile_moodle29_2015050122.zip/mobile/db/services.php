<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External functions and service definitions.
 *
 * @package    local_mobile
 * @copyright  2014 Juan Leyva <juan@moodle.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

$functions = array(

    'local_mobile_core_completion_mark_course_self_completed' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'core_completion_mark_course_self_completed',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Update the course completion status for the current user (if course self-completion is enabled).',
        'type'        => 'write',
    ),

    'local_mobile_core_course_get_course_module' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'core_course_get_course_module',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Return information about a course module',
        'type'        => 'read'
    ),

    'local_mobile_core_course_get_course_module_by_instance' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'core_course_get_course_module_by_instance',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Return information about a given module name and instance id',
        'type'        => 'read'
    ),

    'local_mobile_core_course_search_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'core_course_search_courses',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Search courses by (name, module, block, tag)',
        'type'          => 'read',
        'capabilities'  => '',
    ),

    'local_mobile_core_enrol_get_course_enrolment_methods' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'core_enrol_get_course_enrolment_methods',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Get the list of course enrolment methods',
        'type'        => 'read',
    ),

    'local_mobile_core_group_get_activity_allowed_groups' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'core_group_get_activity_allowed_groups',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Gets a list of groups that the user is allowed to access within the specified activity.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_core_group_get_activity_groupmode' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'core_group_get_activity_groupmode',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Returns effective groupmode used in a given activity.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_enrol_guest_get_instance_info' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'enrol_guest_get_instance_info',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Return guest enrolment instance information.',
        'type'        => 'read'
    ),

    'local_mobile_enrol_self_enrol_user' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'enrol_self_enrol_user',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Self enrol the current user in the given course.',
        'type'        => 'write'
    ),

    'local_mobile_mod_assign_view_grading_table' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_assign_view_grading_table',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface page: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mmod/assign:view, mod/assign:viewgrades'
    ),

    'local_mobile_mod_book_view_book' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_book_view_book',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface folder: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/book:read'
    ),

    'local_mobile_mod_chat_get_chat_latest_messages' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_chat_get_chat_latest_messages',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Get the latest messages from the given chat session.',
        'type'          => 'read',
        'capabilities'  => 'mod/chat:chat'
    ),

    'local_mobile_mod_chat_get_chat_users' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_chat_get_chat_users',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Get the list of users in the given chat session.',
        'type'          => 'read',
        'capabilities'  => 'mod/chat:chat'
    ),

    'local_mobile_mod_chat_get_chats_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_chat_get_chats_by_courses',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Retrieve chat activities by courses.',
        'type'          => 'read',
        'capabilities'  => 'mod/chat:chat'
    ),

    'local_mobile_mod_chat_login_user' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_chat_login_user',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Log a user into a chat room in the given chat.',
        'type'          => 'write',
        'capabilities'  => 'mod/chat:chat'
    ),


    'local_mobile_mod_chat_send_chat_message' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_chat_send_chat_message',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Send a message on the given chat session.',
        'type'          => 'write',
        'capabilities'  => 'mod/chat:chat'
    ),

    'local_mobile_mod_chat_view_chat' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_chat_view_chat',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface folder: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/chat:chat'
    ),

    'local_mobile_mod_choice_delete_choice_responses' => array(
        'classname'   => 'local_mobile_external',
        'methodname'  => 'mod_choice_delete_choice_responses',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Delete the given submitted responses in a choice',
        'type'        => 'write',
        'capabilities'  => 'mod/choice:choose'
    ),

    'local_mobile_mod_choice_get_choice_options' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_choice_get_choice_options',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Retrieve options for a specific choice.',
        'type'          => 'read',
        'capabilities'  => 'mod/choice:choose'
    ),

    'local_mobile_mod_choice_get_choice_results' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_choice_get_choice_results',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Retrieve users results for a specific choice.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_mod_choice_get_choices_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_choice_get_choices_by_courses',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Retrieve choice activities by courses.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_mod_choice_submit_choice_response' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_choice_submit_choice_response',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Submit responses to a specific choice item.',
        'type'          => 'write',
        'capabilities'  => 'mod/choice:choose'
    ),

    'local_mobile_mod_choice_view_choice' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_choice_view_choice',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface folder: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => ''
    ),

    'local_mobile_mod_folder_view_folder' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_folder_view_folder',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface folder: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/folder:view'
    ),

    'local_mobile_mod_forum_add_discussion' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_forum_add_discussion',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Add a new discussion into an existing forum.',
        'type'          => 'write',
        'capabilities'  => 'mod/forum:startdiscussion'
    ),

    'local_mobile_mod_forum_add_discussion_post' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_forum_add_discussion_post',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Create new posts into an existing discussion.',
        'type'          => 'write',
        'capabilities'  => 'mod/forum:replypost'
    ),

    'local_mobile_mod_forum_can_add_discussion' => array(
        'classname' => 'local_mobile_external',
        'methodname' => 'mod_forum_can_add_discussion',
        'classpath'   => 'local/mobile/externallib.php',
        'description' => 'Check if the current user can add discussions in the given forum (and optionally for the given group).',
        'type' => 'read'
    ),

    'local_mobile_mod_forum_get_forums_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_forum_get_forums_by_courses',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Returns a list of forum instances in a provided set of courses, if
            no courses are provided then all the forum instances the user has access to will be
            returned.',
        'type'          => 'read',
        'capabilities'  => 'mod/forum:viewdiscussion'
    ),

    'local_mobile_mod_imscp_view_imscp' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_imscp_view_imscp',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface folder: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/imscp:view'
    ),

    'local_mobile_mod_lti_get_ltis_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_lti_get_ltis_by_courses',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Returns a list of external tool instances in a provided set of courses, if
                            no courses are provided then all the external tool instances the user has access to will be returned.',
        'type'          => 'read',
        'capabilities'  => 'mod/lti:view'
    ),

    'local_mobile_mod_lti_get_tool_launch_data' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_lti_get_tool_launch_data',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Return the launch data for a given external tool.',
        'type'          => 'read',
        'capabilities'  => 'mod/lti:view'
    ),

    'local_mobile_mod_lti_view_lti' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_lti_view_lti',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Trigger the course module viewed event and update the module completion status.',
        'type'          => 'write',
        'capabilities'  => 'mod/lti:view'
    ),

    'local_mobile_mod_page_view_page' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_page_view_page',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface page: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/page:view'
    ),

    'local_mobile_mod_resource_view_resource' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_resource_view_resource',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface page: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/resource:view'
    ),

    'local_mobile_mod_scorm_view_scorm' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_scorm_view_scorm',
        'description'   => 'Trigger the course module viewed event.',
        'type'          => 'write',
        'capabilities'  => ''
    ),

    'local_mobile_mod_scorm_get_scorm_attempt_count' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_scorm_get_scorm_attempt_count',
        'description'   => 'Return the number of attempts done by a user in the given SCORM.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_mod_scorm_get_scorm_scoes' => array(
        'classname' => 'local_mobile_external',
        'methodname' => 'mod_scorm_get_scorm_scoes',
        'description' => 'Returns a list containing all the scoes data related to the given scorm id',
        'type' => 'read',
        'capabilities' => ''
    ),

    'local_mobile_mod_scorm_get_scorm_user_data' => array(
        'classname' => 'local_mobile_external',
        'methodname' => 'mod_scorm_get_scorm_user_data',
        'description' => 'Retrieves user tracking and SCO data and default SCORM values',
        'type' => 'read',
        'capabilities' => ''
    ),

    'local_mobile_mod_scorm_insert_scorm_tracks' => array(
        'classname' => 'local_mobile_external',
        'methodname' => 'mod_scorm_insert_scorm_tracks',
        'description' => 'Saves a scorm tracking record.
                          It will overwrite any existing tracking data for this attempt.
                          Validation should be performed before running the function to ensure the user will not lose any existing
                          attempt data.',
        'type' => 'write',
        'capabilities' => 'mod/scorm:savetrack'
    ),

    'local_mobile_mod_scorm_get_scorm_sco_tracks' => array(
        'classname' => 'local_mobile_external',
        'methodname' => 'mod_scorm_get_scorm_sco_tracks',
        'description' => 'Retrieves SCO tracking data for the given user id and attempt number',
        'type' => 'read',
        'capabilities' => ''
    ),

    'local_mobile_mod_scorm_get_scorms_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_scorm_get_scorms_by_courses',
        'description'   => 'Returns a list of scorm instances in a provided set of courses, if
                            no courses are provided then all the scorm instances the user has access to will be returned.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_mod_survey_get_questions' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_survey_get_questions',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Get the complete list of questions for the survey, including subquestions.',
        'type'          => 'read',
        'capabilities'  => 'mod/survey:participate'
    ),

    'local_mobile_mod_survey_get_surveys_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_survey_get_surveys_by_courses',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Returns a list of survey instances in a provided set of courses,
                            if no courses are provided then all the survey instances the user has access to will be returned.',
        'type'          => 'read',
        'capabilities'  => ''
    ),

    'local_mobile_mod_survey_submit_answers' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_survey_submit_answers',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Submit the answers for a given survey.',
        'type'          => 'write',
        'capabilities'  => 'mod/survey:participate'
    ),

    'local_mobile_mod_survey_view_survey' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_survey_view_survey',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Trigger the course module viewed event and update the module completion status.',
        'type'          => 'write',
        'capabilities'  => 'mod/survey:participate'
    ),

    'local_mobile_mod_url_view_url' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_url_view_url',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Simulate the view.php web interface page: trigger events, completion, etc...',
        'type'          => 'write',
        'capabilities'  => 'mod/url:view'
    ),

    'local_mobile_mod_glossary_get_glossaries_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_glossaries_by_courses',
        'description'   => 'Retrieve a list of glossaries from several courses.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_view_glossary' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_view_glossary',
        'description'   => 'Notify the glossary as being viewed.',
        'type'          => 'write',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_view_entry' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_view_entry',
        'description'   => 'Notify a glossary entry as being viewed.',
        'type'          => 'write',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_letter' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_letter',
        'description'   => 'Browse entries by letter.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_date' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_date',
        'description'   => 'Browse entries by date.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_categories' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_categories',
        'description'   => 'Get the categories.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_category' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_category',
        'description'   => 'Browse entries by category.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_authors' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_authors',
        'description'   => 'Get the authors.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_author' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_author',
        'description'   => 'Browse entries by author.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_author_id' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_author_id',
        'description'   => 'Browse entries by author ID.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_search' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_search',
        'description'   => 'Browse entries by search query.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_by_term' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_by_term',
        'description'   => 'Browse entries by term (concept or alias).',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_glossary_get_entries_to_approve' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entries_to_approve',
        'description'   => 'Browse entries to be approved.',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:approve'
    ),

    'local_mobile_mod_glossary_get_entry_by_id' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_glossary_get_entry_by_id',
        'description'   => 'Get an entry by ID',
        'type'          => 'read',
        'classpath'     => 'local/mobile/externallib.php',
        'capabilities'  => 'mod/glossary:view'
    ),

    'local_mobile_mod_wiki_get_wikis_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_get_wikis_by_courses',
        'description'   => 'Returns a list of wiki instances in a provided set of courses, if ' .
                           'no courses are provided then all the wiki instances the user has access to will be returned.',
        'type'          => 'read',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),

    'local_mobile_mod_wiki_view_wiki' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_view_wiki',
        'description'   => 'Trigger the course module viewed event and update the module completion status.',
        'type'          => 'write',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),

    'local_mobile_mod_wiki_view_page' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_view_page',
        'description'   => 'Trigger the page viewed event and update the module completion status.',
        'type'          => 'write',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),

    'local_mobile_mod_wiki_get_subwikis' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_get_subwikis',
        'description'   => 'Returns the list of subwikis the user can see in a specific wiki.',
        'type'          => 'read',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),
    'local_mobile_mod_wiki_get_subwiki_pages' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_get_subwiki_pages',
        'description'   => 'Returns the list of pages for a specific subwiki.',
        'type'          => 'read',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),

    'local_mobile_mod_wiki_get_page_contents' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_get_page_contents',
        'description'   => 'Returns the contents of a page.',
        'type'          => 'read',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),

    'local_mobile_mod_wiki_get_subwiki_files' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_get_subwiki_files',
        'description'   => 'Returns the list of files for a specific subwiki.',
        'type'          => 'read',
        'capabilities'  => 'mod/wiki:viewpage',
        'classpath'     => 'local/mobile/externallib.php',
    ),

    'local_mobile_mod_wiki_get_page_for_editing' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_get_page_for_editing',
        'description'   => 'Locks and retrieves info of page-section to be edited.',
        'type'          => 'write',
        'capabilities'  => 'mod/wiki:editpage',
    ),

    'local_mobile_mod_wiki_new_page' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_new_page',
        'description'   => 'Create a new page in a subwiki.',
        'type'          => 'write',
        'capabilities'  => 'mod/wiki:editpage',
    ),

    'local_mobile_mod_wiki_edit_page' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_wiki_edit_page',
        'description'   => 'Save the contents of a page.',
        'type'          => 'write',
        'capabilities'  => 'mod/wiki:editpage',
    ),

    'local_mobile_mod_quiz_get_quizzes_by_courses' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_quizzes_by_courses',
        'description'   => 'Returns a list of quizzes in a provided list of courses,
                            if no list is provided all quizzes that the user can view will be returned.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_view_quiz' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_view_quiz',
        'description'   => 'Trigger the course module viewed event and update the module completion status.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_get_user_attempts' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_user_attempts',
        'description'   => 'Return a list of attempts for the given quiz and user.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_get_user_best_grade' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_user_best_grade',
        'description'   => 'Get the best current grade for the given user on a quiz.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_get_combined_review_options' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_combined_review_options',
        'description'   => 'Combines the review options from a number of different quiz attempts.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_start_attempt' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_start_attempt',
        'description'   => 'Starts a new attempt at a quiz.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_get_attempt_data' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_attempt_data',
        'description'   => 'Returns information for the given attempt page for a quiz attempt in progress.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_get_attempt_summary' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_attempt_summary',
        'description'   => 'Returns a summary of a quiz attempt before it is submitted.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_save_attempt' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_save_attempt',
        'description'   => 'Processes save requests during the quiz.
                            This function is intended for the quiz auto-save feature.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_process_attempt' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_process_attempt',
        'description'   => 'Process responses during an attempt at a quiz and also deals with attempts finishing.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_get_attempt_review' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_attempt_review',
        'description'   => 'Returns review information for the given finished attempt, can be used by users or teachers.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:reviewmyattempts',
    ),

    'local_mobile_mod_quiz_view_attempt' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_view_attempt',
        'description'   => 'Trigger the attempt viewed event.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_view_attempt_summary' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_view_attempt_summary',
        'description'   => 'Trigger the attempt summary viewed event.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:attempt',
    ),

    'local_mobile_mod_quiz_view_attempt_review' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_view_attempt_review',
        'description'   => 'Trigger the attempt reviewed event.',
        'type'          => 'write',
        'capabilities'  => 'mod/quiz:reviewmyattempts',
    ),

    'local_mobile_mod_quiz_get_quiz_feedback_for_grade' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_quiz_feedback_for_grade',
        'description'   => 'Get the feedback text that should be show to a student who got the given grade in the given quiz.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_get_quiz_access_information' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_quiz_access_information',
        'description'   => 'Return access information for a given quiz.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_get_attempt_access_information' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_attempt_access_information',
        'description'   => 'Return access information for a given attempt in a quiz.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_quiz_get_quiz_required_qtypes' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_quiz_get_quiz_required_qtypes',
        'description'   => 'Return the potential question types that would be required for a given quiz.',
        'type'          => 'read',
        'capabilities'  => 'mod/quiz:view',
    ),

    'local_mobile_mod_assign_save_submission' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_assign_save_submission',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Save a submission.',
        'type'          => 'write',
        'capabilities'  => 'mod/assign:submit',
    ),

    'local_mobile_mod_assign_view_submission_status' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_assign_view_submission_status',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Trigger the submission status viewed event.',
        'type'          => 'write',
        'capabilities'  => 'mod/assign:view',
    ),

    'local_mobile_mod_assign_get_submission_status' => array(
        'classname'     => 'local_mobile_external',
        'methodname'    => 'mod_assign_get_submission_status',
        'classpath'     => 'local/mobile/externallib.php',
        'description'   => 'Returns information about an assignment submission status for a given user.',
        'type'          => 'read',
        'capabilities'  => 'mod/assign:view',
    ),

      'local_mobile_mod_assign_view_assign' => array(
            'classname'     => 'local_mobile_external',
            'methodname'    => 'mod_assign_view_assign',
            'classpath'     => 'local/mobile/externallib.php',
            'description'   => 'Update the module completion status.',
            'type'          => 'write',
            'capabilities'  => 'mod/assign:view',
      ),
      'local_mobile_core_course_get_user_navigation_options' => array(
            'classname' => 'local_mobile_external',
            'methodname' => 'core_course_get_user_navigation_options',
            'classpath' => 'local/mobile/externallib.php',
            'description' => 'Return a list of navigation options in a set of courses that are avaialable or not for the current user.',
            'type' => 'read',
      ),
      'local_mobile_core_course_get_user_administration_options' => array(
            'classname' => 'local_mobile_external',
            'methodname' => 'core_course_get_user_administration_options',
            'classpath' => 'local/mobile/externallib.php',
            'description' => 'Return a list of administration options in a set of courses that are avaialable or not for the current
                            user.',
            'type' => 'read',
      ),
      'local_mobile_tool_mobile_get_config' => array(
            'classname'   => 'local_mobile_external',
            'methodname'  => 'tool_mobile_get_config',
            'classpath' => 'local/mobile/externallib.php',
            'description' => 'Returns a list of the site configurations, filtering by section.',
            'type'        => 'read',
      ),
      'local_mobile_core_badges_get_user_badges' => array(
            'classname' => 'local_mobile_external',
            'methodname' => 'core_badges_get_user_badges',
            'classpath' => 'local/mobile/externallib.php',
            'description' => 'Returns the list of badges awarded to a user.',
            'type' => 'read',
            'capabilities'  => 'moodle/badges:viewotherbadges',
      ),
    'local_mobile_core_course_get_courses_by_field' => array(
        'classname' => 'local_mobile_external',
        'methodname' => 'core_course_get_courses_by_field',
        'classpath' => 'local/mobile/externallib.php',
        'description' => 'Get courses matching a specific field (id/s, shortname, idnumber, category)',
        'type' => 'read',
    ),
);

$services = array(
   'Moodle Mobile additional features service'  => array(
        'functions' => array (

            'core_calendar_get_calendar_events',
            'core_comment_get_comments',
            'core_completion_get_activities_completion_status',
            'core_completion_get_course_completion_status',
            'core_completion_update_activity_completion_status_manually',
            'core_course_get_contents',
            'core_course_get_courses',
            'core_course_view_course',
            'core_enrol_get_enrolled_users',
            'core_enrol_get_users_courses',
            'core_get_component_strings',   // Don't remove this, the app relies on this to check the min version.
            'core_group_get_course_user_groups',
            'core_files_get_files',
            'core_message_block_contacts',
            'core_message_create_contacts',
            'core_message_delete_contacts',
            'core_message_get_blocked_users',
            'core_message_get_contacts',
            'core_message_get_messages',
            'core_message_mark_message_read',
            'core_message_search_contacts',
            'core_notes_delete_notes',
            'core_message_send_instant_messages',
            'core_message_unblock_contacts',
            'core_notes_create_notes',
            'core_notes_get_course_notes',
            'core_notes_view_notes',
            'core_rating_get_item_ratings',
            'core_user_add_user_device',
            'core_user_add_user_private_files',
            'core_user_get_course_user_profiles',
            'core_user_get_users_by_field',
            'core_user_get_users_by_id',
            'core_user_remove_user_device',
            'core_user_view_user_list',
            'core_user_view_user_profile',
            'core_webservice_get_site_info',
            'gradereport_user_get_grades_table',
            'gradereport_user_view_grade_report',
            'message_airnotifier_are_notification_preferences_configured',
            'message_airnotifier_is_system_configured',
            'mod_assign_get_assignments',
            'mod_assign_get_submissions',
            'mod_assign_submit_for_grading',
            'mod_assign_get_user_mappings',
            'mod_data_get_databases_by_courses',
            'mod_forum_get_forum_discussions_paginated',
            'mod_forum_get_forum_discussion_posts',
            'mod_forum_view_forum',
            'mod_forum_view_forum_discussion',
            'local_mobile_core_completion_mark_course_self_completed',
            'local_mobile_core_course_get_course_module',
            'local_mobile_core_course_get_course_module_by_instance',
            'local_mobile_core_course_search_courses',
            'local_mobile_core_course_get_user_navigation_options',
            'local_mobile_core_course_get_user_administration_options',
            'local_mobile_mod_assign_view_assign',
            'local_mobile_core_enrol_get_course_enrolment_methods',
            'local_mobile_core_group_get_activity_allowed_groups',
            'local_mobile_core_group_get_activity_groupmode',
            'local_mobile_enrol_guest_get_instance_info',
            'local_mobile_enrol_self_enrol_user',
            'local_mobile_mod_book_view_book',
            'local_mobile_mod_chat_get_chat_latest_messages',
            'local_mobile_mod_chat_get_chat_users',
            'local_mobile_mod_chat_get_chats_by_courses',
            'local_mobile_mod_chat_login_user',
            'local_mobile_mod_chat_send_chat_message',
            'local_mobile_mod_chat_view_chat',
            'local_mobile_mod_choice_delete_choice_responses',
            'local_mobile_mod_choice_get_choice_options',
            'local_mobile_mod_choice_get_choice_results',
            'local_mobile_mod_choice_get_choices_by_courses',
            'local_mobile_mod_choice_submit_choice_response',
            'local_mobile_mod_choice_view_choice',
            'local_mobile_mod_folder_view_folder',
            'local_mobile_mod_forum_add_discussion',
            'local_mobile_mod_forum_add_discussion_post',
            'local_mobile_mod_forum_can_add_discussion',
            'local_mobile_mod_forum_get_forums_by_courses',
            'local_mobile_mod_imscp_view_imscp',
            'local_mobile_mod_lti_get_ltis_by_courses',
            'local_mobile_mod_lti_get_tool_launch_data',
            'local_mobile_mod_lti_view_lti',
            'local_mobile_mod_page_view_page',
            'local_mobile_mod_resource_view_resource',
            'local_mobile_mod_scorm_get_scorm_attempt_count',
            'local_mobile_mod_scorm_get_scorm_sco_tracks',
            'local_mobile_mod_scorm_get_scorm_scoes',
            'local_mobile_mod_scorm_get_scorm_user_data',
            'local_mobile_mod_scorm_get_scorms_by_courses',
            'local_mobile_mod_scorm_insert_scorm_tracks',
            'local_mobile_mod_scorm_view_scorm',
            'local_mobile_mod_survey_get_questions',
            'local_mobile_mod_survey_get_surveys_by_courses',
            'local_mobile_mod_survey_submit_answers',
            'local_mobile_mod_survey_view_survey',
            'local_mobile_mod_url_view_url',
            'local_mobile_mod_glossary_get_glossaries_by_courses',
            'local_mobile_mod_glossary_view_glossary',
            'local_mobile_mod_glossary_view_entry',
            'local_mobile_mod_glossary_get_entries_by_letter',
            'local_mobile_mod_glossary_get_entries_by_date',
            'local_mobile_mod_glossary_get_categories',
            'local_mobile_mod_glossary_get_entries_by_category',
            'local_mobile_mod_glossary_get_authors',
            'local_mobile_mod_glossary_get_entries_by_author',
            'local_mobile_mod_glossary_get_entries_by_author_id',
            'local_mobile_mod_glossary_get_entries_by_search',
            'local_mobile_mod_glossary_get_entries_by_term',
            'local_mobile_mod_glossary_get_entries_to_approve',
            'local_mobile_mod_glossary_get_entry_by_id',
            'local_mobile_mod_quiz_get_quizzes_by_courses',
            'local_mobile_mod_quiz_view_quiz',
            'local_mobile_mod_quiz_get_user_attempts',
            'local_mobile_mod_quiz_get_user_best_grade',
            'local_mobile_mod_quiz_get_combined_review_options',
            'local_mobile_mod_quiz_start_attempt',
            'local_mobile_mod_quiz_get_attempt_data',
            'local_mobile_mod_quiz_get_attempt_summary',
            'local_mobile_mod_quiz_save_attempt',
            'local_mobile_mod_quiz_process_attempt',
            'local_mobile_mod_quiz_get_attempt_review',
            'local_mobile_mod_quiz_view_attempt',
            'local_mobile_mod_quiz_view_attempt_summary',
            'local_mobile_mod_quiz_view_attempt_review',
            'local_mobile_mod_quiz_get_quiz_feedback_for_grade',
            'local_mobile_mod_quiz_get_quiz_access_information',
            'local_mobile_mod_quiz_get_attempt_access_information',
            'local_mobile_mod_quiz_get_quiz_required_qtypes',
            'local_mobile_mod_wiki_get_wikis_by_courses',
            'local_mobile_mod_wiki_view_wiki',
            'local_mobile_mod_wiki_view_page',
            'local_mobile_mod_wiki_get_subwikis',
            'local_mobile_mod_wiki_get_subwiki_pages',
            'local_mobile_mod_wiki_get_page_contents',
            'local_mobile_mod_wiki_get_subwiki_files',
            'local_mobile_mod_wiki_get_page_for_editing',
            'local_mobile_mod_wiki_new_page',
            'local_mobile_mod_wiki_edit_page',
            'local_mobile_mod_assign_save_submission',
            'local_mobile_mod_assign_get_submission_status',
            'local_mobile_mod_assign_view_submission_status',
            'local_mobile_mod_assign_view_grading_table',
            'local_mobile_tool_mobile_get_config',
            'local_mobile_core_badges_get_user_badges',
            'local_mobile_core_course_get_courses_by_field',
            'core_course_get_categories',
        ),
        'enabled' => 0,
        'restrictedusers' => 0,
        'shortname' => 'local_mobile',
        'downloadfiles' => 1,
        'uploadfiles' => 1
    ),
);