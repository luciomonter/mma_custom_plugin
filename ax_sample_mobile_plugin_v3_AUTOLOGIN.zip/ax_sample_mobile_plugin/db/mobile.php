<?php
/* AX RESTRICTION for PLUGIN DEVELOPMENT*/
/* todo: configure via admin panel */

global $USER;
$RESTRICT_PLUGIN_TO_USERS_FOR_DEVELOPMENT = false;
/// su tincan sim1 => id=3 | sim2 => id=20
$authorizedDevelpmentUsersIds = array(1,2,3,4);

if((!$RESTRICT_PLUGIN_TO_USERS_FOR_DEVELOPMENT) || in_array($USER->id, $authorizedDevelpmentUsersIds)) {

$addons = array(
    "ax_sample_mobile_plugin" => array( // Plugin identifier
    	'handlers' => array( // Different places where the plugin will display content.
            'ax_sample_mobile_plugin' => array( // Handler unique name (alphanumeric).
            	'displaydata' => array(
                	/*'icon' => $CFG->wwwroot . '/local/ax_sample_mobile_plugin/pix/icon.png',*/
					'icon' => 'cart',
                	'class' => '',
                	'title' => 'ax_sample_mobile_plugin_title',
					'priority ' => 710
            	),
 
            	'delegate' => 'CoreMainMenuDelegate', // Delegate (where to display the link to the plugin)
				/*'restrict' => array('users' => array(1, 20)),*/ /// doesn't work anyway
            	'method' => 'mobile_test_view', // Main function in \mod_certificate\output\mobile
				/*
				'styles' => [
                    'url' => '/local/ax_sample_mobile_plugin/css/mobilestyles.css',
                    'version' => 1 /// seems to work only for iphone, use the one inside template
                ],
				*/
            	'offlinefunctions' => array(
				
                 )       // Function that needs to be downloaded for offline.
            )
    	),
		'lang' => array(	// Language strings that are used in all the handlers.
					//array('pluginname', 'ax_sample_mobile_plugin')
					array('ax_sample_mobile_plugin_title', 'local_ax_sample_mobile_plugin')
					,array('una_label_di_prova', 'local_ax_sample_mobile_plugin')
					,array('label_bottone_nuova_pagina', 'local_ax_sample_mobile_plugin')
					,array('label_bottone_call_ws', 'local_ax_sample_mobile_plugin')
					
				),
    )
);

} else {
	/// Disable plugin
	$addons = array();
}

?>