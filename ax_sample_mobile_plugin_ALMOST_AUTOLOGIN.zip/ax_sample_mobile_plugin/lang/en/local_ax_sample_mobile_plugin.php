<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     local_ax_sample_mobile_plugin
 * @category    string
 * @copyright   2018 Skilla <info@skilla.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

//defined('MOODLE_INTERNAL') || die();


$string['name'] = 'Ax - sample mobile plugin';
$string['pluginname'] = 'Ax - sample mobile plugin';
$string['ax_sample_mobile_plugin_title'] = 'AX sample mobile plugin ENG';
$string['una_label_di_prova'] = 'Una label che viene in ENG';
$string['label_bottone_nuova_pagina'] = 'new NAViga page';
$string['label_bottone_call_ws'] = 'call WS on server';

/*
$string['pluginname'] = 'AX sample mobile plugin';
$string['ax_sample_mobile_plugin'] = 'AX sample mobile plugin 1';
$string['ax_sample_mobile_plugin:ax_sample_mobile_plugin'] = 'AX sample mobile plugin 2';
$string['ax_sample_mobile_plugin_title'] = 'AX sample mobile plugin 3';

/*
$string['axifications'] = 'AX ification';
$string['ax_local_mobile'] = 'AX ification ITA 1';
$string['ax_local_sample_mobile.ax_local_mobile'] = 'AX ification ITA 2';
$string['plugin.ax_local_sample_mobile.ax_local_mobile'] = 'AX ification ITA 3';
$string['local_ax_sample_mobile_plugin'] = 'AX ification ITA 4';
$string['ax_sample_mobile_plugin'] = 'AX ification ITA 5';
$string['plugin.ax_sample_mobile_plugin.ax_sample_mobile_plugin'] = 'AX ification ITA 6';
$string['ax_sample_mobile_plugin.ax_sample_mobile_plugin'] = 'AX ification ITA 7';
$string['ax_sample_mobile_plugin'] = 'AX ification ITA 8';
$string['plugin.ax_sample_mobile_plugin'] = 'AX ification ITA 9';
*/

