<?php
namespace local_ax_sample_mobile_plugin\output;
 
defined('MOODLE_INTERNAL') || die();
 
use context_module;
//use ax_local_sample_mobile_external;
 
/**
 * Mobile output class for certificate
 *
 * @package	mod_certificate
 * @copyright  2018 Juan Leyva
 * @license	http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mobile {
 
	/**
 	* Returns the certificate course view for the mobile app.
 	* @param  array $args Arguments from tool_mobile_get_content WS
 	*
 	* @return array   	HTML, javascript and otherdata
 	*/
    public static function mobile_test_view($args) {
		global $OUTPUT, $USER, $DB;
        $args = (object) $args;

		$data = array(
        	'url_for_iframe' => "/course/view.php?id=8",
        	'var_name_1' => "giao1",
        	'array_var_name_2' => array("uno","due","tre")
		);
		
		
		//'html' => '<h1>hello Ciuciotto : </h1>'
		//'html' => $OUTPUT->render_from_template('templates/mobile_view_page', $data)
		//'restrict' => array('users' => array(1, 2), 'courses' => array(3, 4)),
		
        return array(
            'templates' => array(
                array(
                    'id' => 'main',
                    'html' => $OUTPUT->render_from_template('local_ax_sample_mobile_plugin/mobile_main_view', $data),
					'cache-view' => false
                ),
            ),
            'javascript' => $OUTPUT->render_from_template('local_ax_sample_mobile_plugin/mobile_main_js', $data),
            'otherdata' => array('otherdata1' => $args->param1),
            'files' => array()
        );
    }	
	
	
	public static function navigate_to_navpage1($args) {
		global $OUTPUT, $USER, $DB;
        $args = (object) $args;

		$data = array(
        	'url_for_iframe' => "http://link.skilla.com/TINCAN/course/view.php?id=8",
        	'var_name_1' => "giao1",
        	'array_var_name_2' => array("uno","due","tre")
		);
		
		
		//'html' => '<h1>hello Ciuciotto : </h1>'
		//'html' => $OUTPUT->render_from_template('templates/mobile_view_page', $data)
		//'restrict' => array('users' => array(1, 2), 'courses' => array(3, 4)),
		
        return array(
            'templates' => array(
                array(
                    'id' => 'main',
                    'html' => $OUTPUT->render_from_template('local_ax_sample_mobile_plugin/mobile_navpage1_view', $data),
					'cache-view' => false
                ),
            ),
            'javascript' => $OUTPUT->render_from_template('local_ax_sample_mobile_plugin/mobile_navpage1_js', $data),
            'otherdata' => array('otherdata1' => $args->param1),
            'files' => array()
        );
    }	
	
	
	
	
    
}

?>